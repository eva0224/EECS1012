package eecs.tm;

import java.util.List;
import java.util.Set;

public class M3
{
    /*
    Given a list containing two or more integers, return a set containing the
    integers in the list that are closest to each other; i.e. the absolute value
    of the difference between them is minimal. The returned set must be sorted.

    For example, if list = [21, 4, 2, 12, 18, 24, 16, 7, 20, 39, -3, 26] then
    the return would be [20, 21]

    */
    public static Set<Integer> closest(List<Integer> list)
    {
        return null; // delete me!
    }
}
