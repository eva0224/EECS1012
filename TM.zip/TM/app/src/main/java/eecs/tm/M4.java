package eecs.tm;

import java.util.List;
import java.util.Map;

public class M4
{
    /*
    Receives a non-empty list of words and return a map containing the
    the distribution statistics of the word lengths. For each length,
    the map contains the length as key and the number of words that
    have that length as value.

    The returned map must be sorted by word length.

    For example, if list = [Hello, Test, Book, Vancouver, Glass, Canada, Light]
    then the return would be: {4=2, 5=3, 6=1, 9=1}

    */
    public static Map<Integer,Integer> lengthChart(List<String> list)
    {
        return null; // delete me!
    }

}
